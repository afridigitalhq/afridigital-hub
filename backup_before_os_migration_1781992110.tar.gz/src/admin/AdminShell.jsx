import React, { useState } from "react";
import DAGSidebarEngine from "./dag/DAGSidebarEngine";

export default function AdminShell({ children }) {
  const [route, setRoute] = useState("/admin/dag");

  const handleNavigate = (path) => {
    setRoute(path);
    window.history.pushState({}, "", path);
  };

  return (
    <div style={{ display: "flex" }}>
      <DAGSidebarEngine onNavigate={handleNavigate} />
      <div style={{ flex: 1, background: "#0a0a0a", minHeight: "100vh" }}>
        {children}
      </div>
    </div>
  );
}
