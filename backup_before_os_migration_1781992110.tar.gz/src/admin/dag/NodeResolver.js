import { DashboardRegistry } from "./DashboardRegistry";

export function resolveNodeByRoute(route) {
  return DashboardRegistry.find((n) => n.route === route);
}

export function resolveNodeById(id) {
  return DashboardRegistry.find((n) => n.id === id);
}
