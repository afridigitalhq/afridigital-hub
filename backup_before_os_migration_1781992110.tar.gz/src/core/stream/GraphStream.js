// AFRIKERNEL_INGESTION_SINGLE_PATH_ENFORCED (AFRISYNC → DAGRuntime ONLY)
// AFRIKERNEL_PRODUCTION_MODE_LOCKED (NO ARCHITECTURE CHANGES ALLOWED)
// AFRIKERNEL_COLLAPSED_SINGLE_RUNTIME_ACTIVE
// AFRISYNC_ONLY_INGRESS_LAYER
// EVENT_SOURCED_KERNEL_ENFORCED (NO DIRECT STATE MUTATION)
// AFRIKERNEL_AUTHORITY_LOCK_V2 (EVENT LOG → DAGRuntime → RENDER ONLY)
// DETERMINISTIC_RENDERER_V2_ACTIVE
// AFRISYNC_CLUSTER_INGESTION_ACTIVE
export class GraphStream {
  constructor(url, onUpdate) {
    this.url = url;
    this.ws = null;
    this.onUpdate = onUpdate;
    this.alive = true;
  }

  connect() {
// AFRISYNC_INGEST_ONLY     this.ws = // REDIRECT_TO_AFRISYNC(this.url);

    this.ws.onopen = () => {
      console.log("🟢 GraphStream connected");
    };

    this.ws.onmessage = (event) => {
      if (!this.alive) return;

      try {
        const data = JSON.parse(event.data);
        this.onUpdate?.(data);
      } catch (e) {}
    };

    this.ws.onclose = () => {
      if (!this.alive) return;
      console.log("🔁 reconnecting graph stream...");
      setTimeout(() => this.connect(), 2000);
    };

    this.ws.onerror = () => {};
  }

  close() {
    this.alive = false;
    this.ws?.close();
  }
}
