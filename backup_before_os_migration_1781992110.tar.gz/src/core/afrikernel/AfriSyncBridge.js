// AFRIKERNEL_INGESTION_SINGLE_PATH_ENFORCED (AFRISYNC → DAGRuntime ONLY)
// AFRIKERNEL_PRODUCTION_MODE_LOCKED (NO ARCHITECTURE CHANGES ALLOWED)
// AFRIKERNEL_COLLAPSED_SINGLE_RUNTIME_ACTIVE
// AFRISYNC_ONLY_INGRESS_LAYER
// EVENT_SOURCED_KERNEL_ENFORCED (NO DIRECT STATE MUTATION)
// AFRIKERNEL_AUTHORITY_LOCK_V2 (EVENT LOG → DAGRuntime → RENDER ONLY)
// AFRISYNC_CLUSTER_INGESTION_ACTIVE
export class AfriSyncBridge {
  constructor(kernel, wsUrl) {
    this.kernel = kernel;
// AFRISYNC_INGEST_ONLY     this.ws = // REDIRECT_TO_AFRISYNC(wsUrl);
    this.buffer = [];
  }

  connect() {
    this.ws.onmessage = (msg) => {
      const event = JSON.parse(msg.data);

      // forward into kernel ONLY (single ingestion path)
      this.kernel.ingest(event);
    };
  }

  broadcast(event) {
    if (this.ws.readyState === 1) {
      this.ws.send(JSON.stringify(event));
    }
  }
}
