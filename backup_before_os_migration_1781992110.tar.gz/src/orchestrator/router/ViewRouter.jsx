import React from "react";

import AfriScanControlPlane from "../../control-plane/ui/AfriScanControlPlane";

export default function ViewRouter({ activeDashboard, dagData }) {

  switch (activeDashboard) {

    case "afriscan":
      return <AfriScanControlPlane dag={dagData} />;

    case "afribank":
      return <div>🏦 AfriBank Module (placeholder)</div>;

    case "afriai":
      return <div>🤖 AfriAI Module (placeholder)</div>;

    case "whatsapp":
      return <div>💬 WhatsApp Module (placeholder)</div>;

    case "security":
      return <div>🛡 Security Module (placeholder)</div>;

    default:
      return <div>🧠 Unknown Module</div>;
  }
}
