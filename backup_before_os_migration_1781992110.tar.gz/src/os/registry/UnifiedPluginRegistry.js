export class UnifiedPluginRegistry {
  constructor() {
    this.plugins = new Map();
  }

  register(name, plugin) {
    if (this.plugins.has(name)) {
      throw new Error("Plugin already exists: " + name);
    }
    this.plugins.set(name, plugin);
  }

  get(name) {
    return this.plugins.get(name);
  }

  list() {
    return [...this.plugins.keys()];
  }

  validate(name) {
    return this.plugins.has(name);
  }
}
